export const TILE_COUNT = 16;
export const GRID_SIZE = 4;
export const BOARD_SIZE = 320;